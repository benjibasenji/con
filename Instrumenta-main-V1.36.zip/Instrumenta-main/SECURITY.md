# Security Policy

## Supported Versions

The following versions of Instrumenta are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 1.x     | :white_check_mark: |

There are currently no vulnerabilities reported.

## Reporting a Vulnerability

If you want to report a vulnerability please raise an issue here:
https://github.com/iappyx/Instrumenta/issues
